package com.example.smartcity_1.ui.job

import com.example.smartcity_1.R
import com.example.smartcity_1.ui.BaseFragment

class SearchJobHomeFragment : BaseFragment(R.layout.searchjobhomefragment) {
    override fun initViews() {

    }
}