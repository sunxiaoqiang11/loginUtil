package com.example.smartcity_1.ui.news

import com.example.smartcity_1.R
import com.example.smartcity_1.ui.BaseFragment

class NewsFragment : BaseFragment(R.layout.fragment_news) {
    override fun initViews() {

    }
}